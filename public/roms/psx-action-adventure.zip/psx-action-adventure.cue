FILE "psx-action-adventure.bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
